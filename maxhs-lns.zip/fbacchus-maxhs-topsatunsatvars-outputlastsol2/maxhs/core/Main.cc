/***********[Main.cc]
Copyright (c) 2012-2013 Jessica Davies, Fahiem Bacchus

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

***********/

#include <errno.h>
#include <signal.h>
#include <iostream>

#ifdef GLUCOSE
#include "glucose/utils/Options.h"
#include "glucose/utils/System.h"
#include "glucose/core/SolverTypes.h"
#else
#include "minisat/utils/Options.h"
#include "minisat/utils/System.h"
#include "minisat/core/SolverTypes.h"
#endif

#include "maxhs/core/MaxSolver.h"
#include "maxhs/core/Wcnf.h"
#include "maxhs/utils/Params.h"

#include <fstream>

#include "maxhs/ifaces/miniSatSolver.h"

using std::cout;

#ifdef GLUCOSE
namespace Minisat = Glucose;
#endif
using namespace Minisat;

static MaxHS::MaxSolver* thesolver{};

static void SIGINT_exit(int signum) {
  if (thesolver) {
    thesolver->printStatsAndExit(signum, 1);
  } else {
    fflush(stdout);
    fflush(stderr);
    // Note that '_exit()' rather than 'exit()' has to be used.
    // The reason is that 'exit()' calls destructors and may cause deadlocks
    // if a malloc/free function happens to be running (these functions are
    // guarded by
    //  locks for multithreaded use).
    _exit(0);
  }
}

constexpr int majorVer{4};
constexpr int minorVer{0};
constexpr int update{0};

int main(int argc, char** argv) {
  try {
    setUsageHelp(
        "USAGE: %s [options] <input-file>\n  where input may be either in "
        "plain or gzipped DIMACS.\n");

    IntOption cpu_lim("A: General MaxHS", "cpu-lim",
                      "Limit on CPU time allowed in seconds.\n", INT32_MAX,
                      IntRange(0, INT32_MAX));
    IntOption mem_lim("A: General MaxHS", "mem-lim",
                      "Limit on memory usage in megabytes.\n", INT32_MAX,
                      IntRange(0, INT32_MAX));
    BoolOption version("A: General MaxHS", "version",
                       "Print version number and exit", false);

    parseOptions(argc, argv, true);
    params.readOptions();
    if (version) {
      cout << "MaxHS " << majorVer << "." << minorVer << "." << update << "\n";
      return (0);
    }
    cout << "c MaxHS " << majorVer << "." << minorVer << "." << update << "\n";
    cout << "c Instance: " << argv[argc - 1] << "\n";
    if (params.printOptions) {
      cout << "c Parameter Settings\n";
      cout << "c ============================================\n";
      printOptionSettings("c ", cout);
      cout << "c ============================================\n";
      cout << "c\n";
    }

    signal(SIGINT, SIGINT_exit);
    signal(SIGXCPU, SIGINT_exit);
    signal(SIGSEGV, SIGINT_exit);
    signal(SIGTERM, SIGINT_exit);
    signal(SIGABRT, SIGINT_exit);

    if (cpu_lim != INT32_MAX) {
      rlimit rl;
      getrlimit(RLIMIT_CPU, &rl);
      if (rl.rlim_max == RLIM_INFINITY || (rlim_t)cpu_lim < rl.rlim_max) {
        rl.rlim_cur = cpu_lim;
        if (setrlimit(RLIMIT_CPU, &rl) == -1)
          cout << "c WARNING! Could not set resource limit: CPU-time.\n";
      }
    }

    if (mem_lim != INT32_MAX) {
      rlim_t new_mem_lim = (rlim_t)mem_lim * 1024 * 1024;
      rlimit rl;
      getrlimit(RLIMIT_AS, &rl);
      if (rl.rlim_max == RLIM_INFINITY || new_mem_lim < rl.rlim_max) {
        rl.rlim_cur = new_mem_lim;
        if (setrlimit(RLIMIT_AS, &rl) == -1)
          cout << "c WARNING! Could not set resource limit: Virtual memory.\n";
      }
    }

    if (argc < 2) {
      cout << "c ERROR: no input file specfied:\n"
              "USAGE: %s [options] <input-file>\n  where input may be either "
              "in plain or gzipped DIMACS.\n";
      exit(0);
    }

    vector<int> nums;
    Weight lastUB;
    /*if (argc > 2) {
      std::string in_text;
      std::ifstream myfile(argv[2]);
      std::string arg2(argv[2]);
      std::string opt_file = arg2.substr(0, arg2.length()-4).append(".opt");
      std::ifstream myfile2(opt_file);
      myfile2 >> lastUB;
      while (getline (myfile, in_text)) {
      }
      int zz = 0;
      for (auto it = in_text.cbegin() ; it != in_text.cend(); ++it) {
        if (*it == '1') {
          zz++;
          nums.push_back(zz);
        }
        else if (*it == '0') {
          zz++;
          nums.push_back(-(zz));
        }
      }
      myfile.close();
      myfile2.close();
    }*/
    if (argc > 2) {
	std::string in_text;
	std::ifstream myfile(argv[2]);
	std::string v_line;
	std::string o_line;
	while (getline (myfile, in_text)) {
		bool tabseen = false;
		int ctr = 0;
		for (auto it = in_text.cbegin() ; it != in_text.cend(); ++it) {
			ctr ++;
			if (!tabseen && *it == '\t') {
				tabseen = true;
			}
			else if (tabseen && *it == 'c') {
				break;
			}
			else if (tabseen && *it == 'v') {
				v_line.assign(in_text.substr(ctr + 1));
				break;
			}
			else if (tabseen && *it == 'o') {
				o_line.assign(in_text.substr(ctr + 1));
				break;
			}
		}
	}
	lastUB = std::stod(o_line);
	int zz = 0;
	for (auto it = v_line.cbegin() ; it != v_line.cend(); ++it) {
		if (*it == '1') {
			zz++;
			nums.push_back(zz);
		}
		else if (*it == '0') {
			zz++;
			nums.push_back(-(zz));
		}
	}
	myfile.close();
    }

    
    Wcnf theFormulaBase{};
    if (!theFormulaBase.inputDimacs(argv[1])) return 1;

    /*cout << "Different wts " << theFormula.nDiffWts() << " = " <<
    theFormula.getDiffWts() << "\n"; cout << "Mutexes "; for(size_t i=0; i <
    theFormula.getMxs().size(); i++) { cout << "#" << i << ". ";
      if(theFormula.isCoreMx(i))
        cout << "Core Mx     ";
      else
        cout << "Non-Core Mx ";
      cout << theFormula.getMxs()[i] << "\n";
    }
    theFormula.printFormula();*/
    time_t t;
    srand((unsigned) time(&t));
    double fixed_size = 80.0;
    int noprogress = 0;
    
    while(true) {
      Wcnf theFormula{};
      theFormula.instance_file_name = theFormulaBase.fileName();
      double stime = cpuTime();
      vector<int> avalue;
      for (int i = 0; i < theFormulaBase.maxVar() + 1; i++) {
        avalue.push_back(0);
      }
      for (auto x : nums) {
        avalue[abs(x)-1] = x < 0 ? -1 : (x > 0 ? 1 : 0);
      }
      vector<Weight> sat_weights;
      for (int i = 0; i < theFormulaBase.maxVar() + 1; i++) {
        sat_weights.push_back((Weight) 1e-100);
      }
      for (size_t i = 0; i < theFormulaBase.nSofts(); i++) {
        auto sc = theFormulaBase.getSoft(i);
        bool satis = false;
        for (auto lt : sc) {
          if ((avalue[var(lt)]<0 && sign(lt)) || (avalue[var(lt)]>0 && !sign(lt))) {
            sat_weights[var(lt)] += theFormulaBase.getWt(i);
            satis = true;
          }
        }
        if (!satis) {
          for (auto lt : sc) {
            sat_weights[var(lt)] -= theFormulaBase.getWt(i);
          }
        }
      }
      vector< std::pair<int, Weight> > ordered_sat_weights;
      for (int i = 0; i < (int) sat_weights.size(); i++) {
        ordered_sat_weights.push_back(std::make_pair(i, pow(rand() / (double) RAND_MAX, 1 / pow(2, (sat_weights[i] < 0 ? 1e-100 : (double) sat_weights[i])))));
      }
      std::sort(ordered_sat_weights.begin(), ordered_sat_weights.end(), [](auto &left, auto &right) { return left.second > right.second; });
      MaxHS_Iface::SatSolver_uniqp sat_solver{new MaxHS_Iface::miniSolver};
      sat_solver->eliminate(true);  // no preprocessing
      for (size_t i = 0; i < theFormulaBase.nHards(); i++) {
        if (!sat_solver->addClause(theFormulaBase.getHard(i))) {
          printf("c ERROR!\n");
        }
      }
      
      auto zz = nums.size();
      vector<lbool> truth_vals(2 * (theFormulaBase.maxVar() + 1), l_Undef);
      int last_index = (int) sat_solver->getForced(0).size();
      for (int i = 0; i < (int) ((zz * fixed_size) / 100); i++) {
        if (truth_vals[toInt(mkLit(ordered_sat_weights[i].first, avalue[ordered_sat_weights[i].first]<0))] == l_True) {
          continue;
        }
        theFormula.addHardClause(mkLit(ordered_sat_weights[i].first, avalue[ordered_sat_weights[i].first]<0));
        truth_vals[toInt(mkLit(ordered_sat_weights[i].first, avalue[ordered_sat_weights[i].first]<0))] = l_True;
        if (!sat_solver->addClause(mkLit(ordered_sat_weights[i].first, avalue[ordered_sat_weights[i].first]<0))) {
          printf("c ERROR!\n");
        }
        auto forced_lits = sat_solver->getForced(last_index);
        for (auto l : forced_lits) {
          theFormula.addHardClause(l);
          truth_vals[toInt(l)] = l_True;
        }
        last_index += (int) forced_lits.size();
        if (last_index >= (int) ((zz * fixed_size) / 100)) {
          break;
        }
      }
      cout << "c neighbourhood time: " << cpuTime() - stime << std::endl;
      for (size_t i = 0; i < theFormulaBase.nSofts(); i++) {
        auto sc = theFormulaBase.getSoft(i);
        auto scw = theFormulaBase.getWt(i);
        bool satis = false;
        for (auto lt: sc) {
          //if (sat_solver->curVal(lt) == l_True) {
          if (truth_vals[toInt(lt)] == l_True) {
            satis = true;
          }
        }
        if (!satis) {
          theFormula.addSoftClause(sc, scw);
        }
      }
      for (size_t i = 0; i < theFormulaBase.nHards(); i++) {
        auto hc = theFormulaBase.getHard(i);
        bool satis = false;
        for (auto lt: hc) {
          //if (sat_solver->curVal(lt) == l_True) {
          if (truth_vals[toInt(lt)] == l_True) {
            satis = true;
          }
        }
        if (!satis) {
          theFormula.addHardClause(hc);
        }
      }
      cout << "c neighbourhood time 2: " << cpuTime() - stime << std::endl;
      theFormula.notVerify();

      MaxHS::MaxSolver S(&theFormula);
      thesolver = &S;
      S.current_best = lastUB;
      S.solve();
      Weight newUB = S.UB() + theFormula.baseCost();
      if (newUB > lastUB) cout << "c DOESNT MAKE SENSE\n";
      if (newUB >= lastUB) {
        noprogress ++;
        cout << "c NO PROGRESS " << noprogress << std::endl;
      }
      else {
        noprogress = 0;
        //fixed_size = 90.0;
        lastUB = newUB;
        nums.clear();
        auto bm = S.getBestModel();
        auto ebm = theFormula.rewriteModelToInput(bm);
        for (size_t i = 0; i < ebm.size(); i++) {
          if (ebm[i] == l_True) {
            nums.push_back((i+1));
          }
          else {
            nums.push_back(-(i+1));
          }
        }
      }
      if (noprogress >= 10) {
        if (fixed_size == 0.0) break;
        fixed_size -= 10;
        cout << "c fixed_size = " << fixed_size << "\n";
        if (fixed_size < 1.0) fixed_size = 0.0;
        noprogress = 0;
      }
      params.readOptions(); //necessary?
    }
    thesolver->printStatsAndExit(-1, 0);
  } catch (const std::bad_alloc&) {
    cout << "c Memory Exceeded\n";
    thesolver->printStatsAndExit(100, 1);
  } catch (...) {
    cout << "c Unknown exception probably memory.\n";
    thesolver->printStatsAndExit(200, 1);
  }
  fflush(stdout);
  fflush(stderr);
  return 0;
}
